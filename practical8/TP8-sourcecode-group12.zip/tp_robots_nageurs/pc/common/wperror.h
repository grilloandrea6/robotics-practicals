#ifndef __WPERROR_H
#define __WPERROR_H

void wperror(const char* str);

#endif
